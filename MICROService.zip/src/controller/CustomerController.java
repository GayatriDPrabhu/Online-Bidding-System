package controller;

import java.util.*;
import java.util.Locale.LanguageRange;

//import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.codehaus.jackson.map.ser.std.StdArraySerializers.BooleanArraySerializer;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import entity.Customer;
import utility.AuthKeyGenerator;
import utility.EmailManager;
import utility.HibSessionBuilder;


@Path("/customer")
public class CustomerController {
	
	@GET
	@Path("/isLoggedIn/{customerId}/{authKey}")
	@Produces(MediaType.TEXT_PLAIN)
	public String isLoggedIn(@PathParam("customerId") int customerId, 
							@PathParam("authKey") int authKey)
	{
		int trueAuthKey=0;
		HibSessionBuilder sessionBuilder = new HibSessionBuilder();
		Session session = sessionBuilder.getSession();
		
		String hql = "SELECT C.authKey FROM Customer C WHERE C.customerId = ?";
		List results = session.createQuery(hql).setParameter(0, customerId).list();
		
		if(results.size() == 1)
		{
			trueAuthKey = (Integer)results.get(0);
		}
		if(trueAuthKey == 0)
		return Boolean.FALSE.toString();
		else if(authKey == trueAuthKey)
		{
			return Boolean.TRUE.toString();
		}
		else
			return Boolean.FALSE.toString();
	}
	
	@POST
	@Path("/getUserId")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public String getUserId(@FormParam("emailId") String emailId)
	{
		int userId = 0;
		HibSessionBuilder sessionBuilder = new HibSessionBuilder();
		Session session = sessionBuilder.getSession();
		
		String hql = "SELECT C.customerId FROM Customer C WHERE C.emailId = ?";
		List results = session.createQuery(hql).setString(0, emailId).list();
		
		if(results.size() == 1)
		{
			userId = (Integer)results.get(0);
		}
		sessionBuilder.close(session);
		
		return Integer.toString(userId);
	}
	
	@POST
	@Path("/isEmailIdAvailable")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public String isEmailIdAvailable(@FormParam("emailId") String emailId)
	{
		int userId = 0;
		HibSessionBuilder sessionBuilder = new HibSessionBuilder();
		Session session = sessionBuilder.getSession();
		
		String hql = "SELECT C.customerId FROM Customer C WHERE C.emailId = ?";
		List results = session.createQuery(hql).setString(0, emailId).list();
		
		if(results.size() == 1)
		{
			userId = (Integer)results.get(0);
		}
		sessionBuilder.close(session);
		
		if(userId == 0)
			return Boolean.TRUE.toString();
		else
			return Boolean.FALSE.toString();
	}
	
	@POST
	@Path("/insertUserData")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public void insertUserData(@FormParam("name") String name, @FormParam("password") String password, @FormParam("contactNo") String contactNo,
			@FormParam("address") String address, @FormParam("emailId") String emailId)
	{
		HibSessionBuilder sessionBuilder = new HibSessionBuilder();
		Session session = sessionBuilder.getSession();
		
		Customer customer = new Customer();
		customer.setName(name);
		customer.setPassword(password);
		customer.setContactNo(contactNo);
		customer.setAddress(address);
		customer.setEmailId(emailId);
		
		Transaction tx = session.beginTransaction();
		session.save(customer);
		tx.commit();
		sessionBuilder.close(session);	
	}
	
	@POST
	@Path("/sendEmail")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public void sendEmail(@FormParam("type") int type, @FormParam("emailId") String emailId)
	{
		//type 1 <= registration email, 2<= send item sold notification
		EmailManager em = new EmailManager();
		em.sendEmail(type, emailId);
	}
	
	@POST
	@Path("/checkLoginCred")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public String checkLoginCred(@FormParam("emailId") String emailId, @FormParam("password") String password)
	{
		int authKey = 0;
		Customer customer = new Customer();
		
		HibSessionBuilder sessionBuilder = new HibSessionBuilder();
		Session session = sessionBuilder.getSession();
		
		String hql = "FROM Customer C WHERE C.emailId = ? and C.password = ?";
		List results = session.createQuery(hql).setString(0, emailId).setString(1, password).list();
		
		if(results.size() == 1)
		{
			customer = (Customer)results.get(0);
			authKey = customer.getAuthKey();
		}
		else {
			//not a valid user credentials, returns 0
			return Integer.toString(authKey);
		}
			if(authKey == 0)
			{
				AuthKeyGenerator keyGenerator = new AuthKeyGenerator();
				authKey = keyGenerator.getAuthKey();
				customer.setAuthKey(authKey);
				//write key down to the DB
				Transaction tx = session.beginTransaction();
				session.save(customer);
				tx.commit();
				
			}
			sessionBuilder.close(session);
			//returns valid login Auth key
			return Integer.toString(authKey);
	}

//	@POST
//	@Path("/updateLoginInfo")
//	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
//	public void updateLoginInfo(@FormParam("emailId") String emailId, @FormParam("location") String location, @Context HttpServletRequest httpRequest)
//	{
//		Locale locale = httpRequest.getLocale();
//	  //update current Data and time here using hibernate	
//		
//	}

	@GET
	@Path("/logOut/{customerId}")
	@Produces(MediaType.TEXT_PLAIN)
	public void logOut(@PathParam("customerId") int customerId)
	{
		Customer customer = new Customer();
		HibSessionBuilder sessionBuilder = new HibSessionBuilder();
		Session session = sessionBuilder.getSession();
		
		String hql = "FROM Customer C WHERE C.customerId = ?";
		List results = session.createQuery(hql).setParameter(0, customerId).list();
		
		if(results.size() == 1)
		{
			customer = (Customer)results.get(0);
			customer.setAuthKey(0);
			Transaction tx = session.beginTransaction();
			session.save(customer);
			tx.commit();
		}
	
	}
	
	@GET
	@Path("/getUserProfile/{customerId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Customer getUserProfile(@PathParam("customerId") int customerId)
	{
		Customer customer = new Customer();
		HibSessionBuilder sessionBuilder = new HibSessionBuilder();
		Session session = sessionBuilder.getSession();
		
		String hql = "FROM Customer C WHERE C.customerId = ?";
		List results = session.createQuery(hql).setParameter(0, customerId).list();
		
		if(results.size() == 1)
		{
			customer = (Customer)results.get(0);
		}
		customer.setProduct(null);
		return customer;
	}	
}
