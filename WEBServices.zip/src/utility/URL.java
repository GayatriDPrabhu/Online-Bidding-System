package utility;

public class URL {

	public String getUrlPrefix() {
		return "http://localhost:8080/DAG-MicroServer/";
	}
}
