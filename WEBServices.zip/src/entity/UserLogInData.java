package entity;

public class UserLogInData {
 private int authKey;
 private int userId;
public int getAuthKey() {
	return authKey;
}
public void setAuthKey(int authKey) {
	this.authKey = authKey;
}
public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}
 
}
